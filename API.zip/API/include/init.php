<?php
   
   
    require_once("config.php");
	require_once("db.php");
    require_once('functions.php');
?>